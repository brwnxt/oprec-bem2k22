<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="shortcut icon" href="assets/images/Logo bem.png" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/login.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light">
        <a class="navbar-brand" href="#"><img src="assets/images/Logo bem.png" width="40"><span class="pl-2 h4 text-white" style="font-family: poppins;"> BEM FIKTI UG </span></a>
    </nav>

    <div class="container mt-5">
        <div class="row align-items-center pt-5">
            <!-- For Demo Purpose -->
            <div class="col-md-5 pr-lg-5 mb-3 mb-md-0">
                <img src="assets/images/Logo bem.png" width="300" class="img-fluid mb-3 d-none d-md-block">
            </div>

            <!-- Registeration Form -->
            <div class="col-md-7 col-lg-6 ml-auto">
                <h4 class="text-center text-white mb-4" >OPEN RECRUITMENT BEM FIKTI GUNADARMA UNIVERSITY 2021/2022</h4>
                <form action="config/login.php" method="POST">
                    <div class="row">

                        <!-- Email Address -->
                        <div class="input-group col-lg-12 mb-4">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white px-4 border-md border-right-0">
                                    <i class="fa fa-envelope text-muted"></i>
                                </span>
                            </div>
                            <input id="email" type="email" name="email" placeholder="Email Address"
                                class="form-control bg-white border-left-0 border-md">
                        </div>
                        
                        <div class="input-group col-lg-12 mb-4">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-white px-4 border-md border-right-0">
                                    <i class="fa fa-lock text-muted"></i>
                                </span>
                            </div>
                            <input id="password" type="password" name="password" placeholder="Password"
                                class="form-control bg-white border-left-0 border-md">
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group col-lg-12 mx-auto mb-4">
                            <button class="btn btn-primary btn-block py-2 font-weight-bold" type="submit" name="submit">LOGIN</button>
                            <h5 class="text-center pt-3 pb-5"> don't have any account ? <a href="register-acc.php"> Sign Up </a> </h5>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <footer class="page-footer font-small blue fixed-bottom bg-light">

        <!-- Copyright -->
        <div class="footer-copyright text-center py-3">Maintained by Biro PTI 2021/2022
        </div>
        <!-- Copyright -->

    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
</body>

</html>