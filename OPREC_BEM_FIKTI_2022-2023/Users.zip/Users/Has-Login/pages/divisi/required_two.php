<option name="choose_two" <?php if($choose_two=="Administrasi Umum"){echo "selected";}?> value="Administrasi Umum">Administrasi Umum</option>
<option name="choose_two" <?php if($choose_two=="Politik dan Kesejahteraan Mahasiswa"){echo "selected";}?> value="Politik dan Kesejahteraan Mahasiswa">Politik dan Kesejahteraan Mahasiswa</option>
<option name="choose_two" <?php if($choose_two=="Akademik"){echo "selected";}?> value="Akademik">Akademik</option>
<option name="choose_two" <?php if($choose_two=="Bisnis dan Kemitraan"){echo "selected";}?> value="Bisnis dan Kemitraan">Bisnis dan Kemitraan</option>
<option name="choose_two" <?php if($choose_two=="Hubungan Masyarakat"){echo "selected";}?> value="Hubungan Masyarakat">Hubungan Masyarakat</option>
<option name="choose_two" <?php if($choose_two=="Penelitian dan Pengembangan"){echo "selected";}?> value="Penelitian dan Pengembangan">Penelitian dan Pengembangan</option>
<option name="choose_two" <?php if($choose_two=="Media"){echo "selected";}?> value="Media">Media</option>
<option name="choose_two" <?php if($choose_two=="Olahraga"){echo "selected";}?> value="Olahraga">Olahraga</option>
<option name="choose_two" <?php if($choose_two=="Pengabdian Masyarakat"){echo "selected";}?> value="Pengabdian Masyarakat">Pengabdian Masyarakat</option>
<option name="choose_two" <?php if($choose_two=="Pengembangan Teknologi Informasi"){echo "selected";}?> value="Pengembangan Teknologi Informasi">Pengembangan Teknologi Informasi</option>
<option name="choose_two" <?php if($choose_two=="Pengembangan Sumber Daya Manusia"){echo "selected";}?> value="Pengembangan Sumber Daya Manusia">Pengembangan Sumber Daya Manusia</option>
<option name="choose_two" <?php if($choose_two=="Seni Budaya"){echo "selected";}?> value="Seni Budaya">Seni Budaya</option>