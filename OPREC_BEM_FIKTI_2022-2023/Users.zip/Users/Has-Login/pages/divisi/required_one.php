<option name="choose_one" <?php if($choose_one=="Administrasi Umum"){echo "selected";}?> value="Administrasi Umum">Administrasi Umum</option>
<option name="choose_one" <?php if($choose_one=="Politik dan Kesejahteraan Mahasiswa"){echo "selected";}?> value="Politik dan Kesejahteraan Mahasiswa">Politik dan Kesejahteraan Mahasiswa</option>
<option name="choose_one" <?php if($choose_one=="Akademik"){echo "selected";}?> value="Akademik">Akademik</option>
<option name="choose_one" <?php if($choose_one=="Bisnis dan Kemitraan"){echo "selected";}?> value="Bisnis dan Kemitraan">Bisnis dan Kemitraan</option>
<option name="choose_one" <?php if($choose_one=="Hubungan Masyarakat"){echo "selected";}?> value="Hubungan Masyarakat">Hubungan Masyarakat</option>
<option name="choose_one" <?php if($choose_one=="Penelitian dan Pengembangan"){echo "selected";}?> value="Penelitian dan Pengembangan">Penelitian dan Pengembangan</option>
<option name="choose_one" <?php if($choose_one=="Media"){echo "selected";}?> value="Media">Media</option>
<option name="choose_one" <?php if($choose_one=="Olahraga"){echo "selected";}?> value="Olahraga">Olahraga</option>
<option name="choose_one" <?php if($choose_one=="Pengabdian Masyarakat"){echo "selected";}?> value="Pengabdian Masyarakat">Pengabdian Masyarakat</option>
<option name="choose_one" <?php if($choose_one=="Pengembangan Teknologi Informasi"){echo "selected";}?> value="Pengembangan Teknologi Informasi">Pengembangan Teknologi Informasi</option>
<option name="choose_one" <?php if($choose_one=="Pengembangan Sumber Daya Manusia"){echo "selected";}?> value="Pengembangan Sumber Daya Manusia">Pengembangan Sumber Daya Manusia</option>
<option name="choose_one" <?php if($choose_one=="Seni Budaya"){echo "selected";}?> value="Seni Budaya">Seni Budaya</option>