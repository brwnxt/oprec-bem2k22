<table class="mb-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">1. </td>
        <td class="pb-2">A. Saya seorang pekerja "keras"</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya bukan seorang pemurung</td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">2. </td>
        <td class="pb-2">A. Saya suka bekerja lebih baik dari orang lain</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menunjukkan caranya melaksanakan sesuatu hal</td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">3. </td>
        <td class="pb-2">A. Saya suka menunjukkan caranya melaksanakan sesuatu hal </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya ingin bekerja sebaik mungkin </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">4. </td>
        <td class="pb-2">A. Saya suka berkelakar </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang mengatakan kepada orang lain, apa yang harus dilakukannya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">5. </td>
        <td class="pb-2">A. Saya suka menggabungkan diri dengan kelompok-kelompok </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka diperhatikan oleh kelompok-kelompok </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">6. </td>
        <td class="pb-2">A. Saya senang bersahabat intim dengan seseorang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang bersahabat dengan sekelompok orang </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">7. </td>
        <td class="pb-2">A. Saya cepat berubah bila hal itu diperlukan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya berusaha untuk intim dengan teman-teman </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">8. </td>
        <td class="pb-2">A. Saya cepat berubah bila hal itu diperlukan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya berusaha untuk intim dengan teman-teman </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">9. </td>
        <td class="pb-2">A. Saya suka "membalas dendam" bila saya benar-benar disakiti </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka melakukan hal-hal yang baru dan berbeda </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">10. </td>
        <td class="pb-2">A. Saya suka mengikuti perintah-perintah yang diberikan kepada saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menyenangkan hati orang yang memimpin saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">11. </td>
        <td class="pb-2">A. Saya mencoba sekuat tenaga </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya seorang yang tertib. Saya meletakkan segala sesuatu pada tempatnya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">12. </td>
        <td class="pb-2">A. Saya membuat orang lain melakukan apa yang saya inginkan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya bukan seorang yang cepat gusar </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">13. </td>
        <td class="pb-2">A. Saya suka mengatakan kepada kelompok, apa yang harus dilakukan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya menekuni satu oekerjaan sampai selesai </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">14. </td>
        <td class="pb-2">A. Saya ingin tampak bersemangat dan menarik </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya ingin menjadi sangat sukses </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">15. </td>
        <td class="pb-2">A. Saya suka menyelaraskan diri dengan kelompok </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka membantu orang lain menentukan pendapatnya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">16. </td>
        <td class="pb-2">A. Saya cemas kalau orang lain tidak menyukai saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang kalau orang-orang memperhatikan saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">17. </td>
        <td class="pb-2">A. Saya suka mencoba sesuatu yang baru </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya lebih suka bekerja bersama orang-orang daripada bekerja sendiri </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">18. </td>
        <td class="pb-2">A. Kadang-kadang saya menyalahkan orang lain bila terjadi suatu kesalahan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya cemas bila seseorang tidak menyukai saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">19. </td>
        <td class="pb-2">A. Saya suka menyenangkan hati orang yang memimpin saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka mencoba pekerjaan-pekerjaan yang baru dan berbeda </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">20. </td>
        <td class="pb-2">A. Saya menyukai petunjuk yang terinci untuk melaksanakan suatu pekerjaan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menyatakan kepada orang lain bila mereka mengganggu saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">21. </td>
        <td class="pb-2">A. Saya selalu mencoba sekuat tenaga </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang bekerja dengan sangat cermat dan hati-hati </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">22. </td>
        <td class="pb-2">A. Saya adalah seorang pemimpin yang baik </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya mengorganisir tugas-tugas secara baik </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">23. </td>
        <td class="pb-2">A. Saya mudah menjadi gusar </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya seorang yang lambat dalam membuat keputusan  </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">24. </td>
        <td class="pb-2">A. Saya senang mengerjakan beberapa pekerjaan pada waktu yang bersamaan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Bila di dalam kelompok, saya lebih suka diam </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">25. </td>
        <td class="pb-2">A. Saya senang bila diundang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya ingin melakukan sesuatu lebih baik dari orang lain </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">26. </td>
        <td class="pb-2">A. Saya suka berteman intim dengan teman-teman saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka memberi nasehat kepada orang lain </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">27. </td>
        <td class="pb-2">A. Saya suka melakukan hal-hal yang baru dan berbeda </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menceritakan keberhasilan saya dalam mengerjakan tugas </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">28. </td>
        <td class="pb-2">A. Bila saya benar, saya suka mempertahankan "mati-matian" </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka bergabung ke dalam suatu kelompok </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">29. </td>
        <td class="pb-2">A. Saya tidak mau berbeda dengan orang lain </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya berusaha untuk sangat intim dengan orang-orang </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">30. </td>
        <td class="pb-2">A. Saya suka diajari mengenai caranya mengerjakan suatu pekerjaan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya mudah merasa jemu (bosan) </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">31. </td>
        <td class="pb-2">A. Saya bekerja "keras" </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya banyak berpikir dan berencana </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">32. </td>
        <td class="pb-2">A. Saya memimpin kelompok </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Hal-hal yang kecil (detil) menarik hati saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">33. </td>
        <td class="pb-2">A. Saya cepat dan mudah mengambil keputusan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya meletakkan segala sesuatu secara rapih dan teratur </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">34. </td>
        <td class="pb-2">A. Tugas-tugas saya kerjakan dengan cepat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya jarang march dan sedih </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">35. </td>
        <td class="pb-2">A. Saya ingin menjadi bagian dari kelompok </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Pada suatu waktu tertentu, saya hanya ingin mengerjakan satu tugas </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">36. </td>
        <td class="pb-2">A. Saya berusaha untuk intim dengan teman-teman saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya berusaha keras untuk menjadi yang terbaik </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">37. </td>
        <td class="pb-2">A. Saya menyukai mode baju baru dan tipe-tipe mobil baru </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya ingin menjadi penanggung jawab bagi orang-orang lain </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">38. </td>
        <td class="pb-2">A. Saya suka berdebat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka diperhatikan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">39. </td>
        <td class="pb-2">A. Saya suka menyenangkan hati orang yang memimpin saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya tertarik menjadi anggota dari suatu kelompok </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">40. </td>
        <td class="pb-2">A. Saya senang mengikuti aturan secara tertib </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka orang-orang mengenal saya benar-benar </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">41. </td>
        <td class="pb-2"> A. Saya mencoba sekuat tenaga</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya sangat menyenangkan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">42. </td>
        <td class="pb-2"> A. Orang lain beranggapan bahwa saya adalah seorang pemimpin yang baik</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya berpikir jauh ke depan dan terperinci </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">43. </td>
        <td class="pb-2"> A. Seringkali saya memanfaatkan peluang</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang memperhatikan hal-hal sampai sekecil-kecilnya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">44. </td>
        <td class="pb-2"> A. Orang lain menganggap saya bekerja cepat</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Orang lain menganggap saya dapat melakukan penataan yang rapi dan teratur </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">45. </td>
        <td class="pb-2"> A. Saya menyukai permainan-permainan dan olahraga</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya sangat menyenangkan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">46. </td>
        <td class="pb-2"> A. Saya senang bila orang-orang dapat intim dan bersahabat</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya selalu berusaha menyelesaikan apa yang telah saya mulai </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">47. </td>
        <td class="pb-2"> A. Saya suka bereksperimen dan mencoba sesuatu yang baru</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka mengerjakan pekerjaan-pekerjaan yang sulit dengan baik </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">48. </td>
        <td class="pb-2"> A. Saya senang diperlakukan secara adil</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang mengajari orang lain bagaimana caranya mengerjakan sesuatu </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">49. </td>
        <td class="pb-2"> A. Saya suka mengerjakan apa yang diharapkan dari saya</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menarik perhatian </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">50. </td>
        <td class="pb-2"> A. Saya suka petunjuk yang terperinci dalam melaksanakan suatu pekerjaan</td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang berada bersama dengan orang-orang lain </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">51. </td>
        <td class="pb-2">A. Saya selalu berusaha mengerjakan tugas secara sempurna </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Orang lain menganggap saya tidak mengenal lelah dalam kerja sehari-hari </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">52. </td>
        <td class="pb-2">A. Saya tergolong tipe pemimpin </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya mudah berteman </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">53. </td>
        <td class="pb-2">A. Saya memanfaatkan peluang-peluang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya banyak berpikir </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">54. </td>
        <td class="pb-2">A. Saya bekerja dengan kecepatan yang mantap dan cepat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang mengerjakan hal-hal yang detil </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">55. </td>
        <td class="pb-2">A. Saya memiliki banyak energi untuk permainan-permainan dan olahraga </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya menempatkan segala sesuatunya secara rapih dan teratur </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">56. </td>
        <td class="pb-2">A. Saya bergaul dengan semua orang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya "pandai mengendalikan diri" </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">57. </td>
        <td class="pb-2">A. Saya ingin berkenalan dengan orang-orang baru dan mengerjakan hal-hal baru </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya selalu ingin menyelesaikan pekerjaan yang sudah saya mulai </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">58. </td>
        <td class="pb-2">A. Biasanya saya bersikeras mengenai apa yang saya yakini </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Biasanya saya suka bekerja "keras" </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">59. </td>
        <td class="pb-2">A. Saya menyukai saran-saran dari orang-orang yang saya kagumi </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya senang mengatur orang lain </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">60. </td>
        <td class="pb-2">A. Saya biarkan orang-orang lain mempengaruhi saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menerima banyak perhatian </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">61. </td>
        <td class="pb-2">A. Biasanya saya bekerja sangat "keras" </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Biasanya saya bekerja cepat </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">62. </td>
        <td class="pb-2">A. Bila saya berbicara, kelompok akan mendengarkan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya terampil mempergunakan alat-alat kerja </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">63. </td>
        <td class="pb-2">A. Saya lambat membina persahabatan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya lambat dalam mengambil keputusan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">64. </td>
        <td class="pb-2">A. Biasanya saya makan secara cepat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka membaca </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">65. </td>
        <td class="pb-2">A. Saya menyukai pekerjaan yang memungkinkan saya "berkeliling" </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya menyukai pekerjaan yang harus dilakukan secara teliti </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">66. </td>
        <td class="pb-2">A. Saya berteman sebanyak mungkin </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya dapat menemukan hal-hal yang telah saya pindahkan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">67. </td>
        <td class="pb-2">A. perencanaan saya jauh ke masa depan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya selalu menyenangkan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">68. </td>
        <td class="pb-2">A. Saya merasa bangga akan nama baik saya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya tetap menekuni satu permasalahan sampai ia terselesaikan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">69. </td>
        <td class="pb-2">A. Saya suka menyenangkan hati orang-orang yang saya kagumi </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka menjadi orang yang berhasil </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5"> 70. </td>
        <td class="pb-2">A. Saya senang bila orang-orang lain mengambil alih keputusan untuk kelompok </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka mengambil keputusan untuk kelompok </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">71. </td>
        <td class="pb-2">A. Saya selalu berusaha sangat "keras" </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya cepat dan mudah mengambil keputusan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">72. </td>
        <td class="pb-2">A. Biasanya kelompok saya mengerjakan hal-hal yang saya inginkan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Biasanya saya tergesa-gesa </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">73. </td>
        <td class="pb-2">A. Saya seringkali merasa lelah </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya lambat dalam mengambil keputusan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">74. </td>
        <td class="pb-2">A. Saya bekerja secara cepat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya mudah mendapat kawan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">75. </td>
        <td class="pb-2">A. Biasanya saya bersemangat atau bergairah </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Sebagian besar waktu saya untuk berpikir </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">76. </td>
        <td class="pb-2">A. Saya sangat hangat kepada orang-orang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya menyukai pekerjaan yang menuntut </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">77. </td>
        <td class="pb-2">A. Saya banyak berpikir dan berencana </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya meletakkan segala sesuatu pada tempatnya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">78. </td>
        <td class="pb-2">A. Saya suka tugas yang perlu ditekuni sampai pada hal sedetilnya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya tidak cepat marah </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">79. </td>
        <td class="pb-2">A. Saya senang mengikuti orang-orang yang saya kagumi </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya selalu menyelesaikan pekerjaan yang saya mulai </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">80. </td>
        <td class="pb-2">A. Saya menyukai petunjuk-petunjuk yang jelas </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka bekerja "keras"  </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">81. </td>
        <td class="pb-2">A. Saya mengejar apa yang saya inginkan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya adalah seorang pemimpin yang baik </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">82. </td>
        <td class="pb-2">A. Saya membuat orang lain bekerja keras </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya adalah seorang yang "gampangan" (tak banyak pertimbangan) </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">83. </td>
        <td class="pb-2">A. Saya membuat keputusan-keputusan secara cepat </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Bicara saya cepat </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">84. </td>
        <td class="pb-2">A. Biasanya saya bekerja tergesa-gesa </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Secara teratur saya berolahraga </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">85. </td>
        <td class="pb-2">A. Saya tidak suka bertemu dengan orang-orang </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya cepat lelah </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">86. </td>
        <td class="pb-2">A. Saya mempunyai banyak sekali teman </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Banyak waktu saya untuk berpikir </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">87. </td>
        <td class="pb-2">A. Saya suka bekerja dengan teori </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka bekerja sedetil-detilnya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">88. </td>
        <td class="pb-2">A. Saya suka bekerja sampai sedetil-detilnya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya suka mengorganisir pekerjaan saya </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">89. </td>
        <td class="pb-2">A. Saya meletakkan segala sesuatu pada tempatnya </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya selalu menyenangkan </td>
    </tr>
</table>

<table class="my-4 h4">
    <tr>
        <td class="pr-2 pb-2 pl-5">90. </td>
        <td class="pb-2">A. Saya senang diberi petunjuk mengenai apa yang harus saya lakukan </td>
    </tr>
    <tr>
        <td></td>
        <td>B. Saya harus menyelesaikan apa yang sudah saya mulai </td>
    </tr>
</table>