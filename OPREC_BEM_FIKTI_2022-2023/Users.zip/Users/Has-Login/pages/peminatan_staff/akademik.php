<div class="row">
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Web Programming", $minatakademik)) echo "checked";?>
                        value="Web Programming"> Web Programming </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Penelitian Ilmiah", $minatakademik)) echo "checked";?>
                        value="Penelitian Ilmiah"> Penelitian Ilmiah </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Mobile Programming", $minatakademik)) echo "checked";?>
                        value="Mobile Programming"> Mobile Programming </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("ERP/System", $minatakademik)) echo "checked";?> value="ERP/System">
                    ERP/System </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Database", $minatakademik)) echo "checked";?> value="Database"> Database
                </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Jaringan Komputer", $minatakademik)) echo "checked";?>
                        value="Jaringan Komputer"> Jaringan Komputer </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Dekstop Programming", $minatakademik)) echo "checked";?>
                        value="Dekstop Programming"> Dekstop Programming </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("FPGA", $minatakademik)) echo "checked";?> value="FPGA"> FPGA </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("IoT", $minatakademik)) echo "checked";?> value="IoT"> IoT </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Embedded System", $minatakademik)) echo "checked";?>
                        value="Embedded System"> Embedded System </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="akademik[]"
                        <?php if (in_array("Robotic", $minatakademik)) echo "checked";?> value="Robotic"> Robotic
                </label>
            </div>
        </div>
    </div>

</div>