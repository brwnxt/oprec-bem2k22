<div class="row">
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Fotografi", $minatmedia_kreatif)) echo "checked";?>
                    value="Fotografi"> Fotografi </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Ilustrasi", $minatmedia_kreatif)) echo "checked";?>
                    value="Ilustrasi"> Ilustrasi </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Desain Grafis", $minatmedia_kreatif)) echo "checked";?>
                    value="Desain Grafis"> Desain Grafis </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Videografi", $minatmedia_kreatif)) echo "checked";?>
                    value="Videografi"> Videografi </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Multimedia", $minatmedia_kreatif)) echo "checked";?>
                    value="Multimedia"> Multimedia </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="media_kreatif[]"
                    <?php if (in_array("Animasi", $minatmedia_kreatif)) echo "checked";?>
                    value="Animasi"> Animasi </label>
            </div>
        </div>
    </div>

</div>