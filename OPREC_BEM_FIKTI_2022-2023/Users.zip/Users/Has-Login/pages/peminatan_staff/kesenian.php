<div class="row">
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Musik", $minatkesenian)) echo "checked";?>
                    value="Musik"> Musik </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Tari Tradisional", $minatkesenian)) echo "checked";?>
                    value="Tari Tradisional"> Tari Tradisional </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Tari Modern", $minatkesenian)) echo "checked";?>
                    value="Tari Modern"> Tari Modern </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Gambar/Lukis", $minatkesenian)) echo "checked";?>
                    value="Gambar/Lukis"> Gambar/Lukis </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Teater/Drama", $minatkesenian)) echo "checked";?>
                    value="Teater/Drama"> Teater/Drama </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Pantun", $minatkesenian)) echo "checked";?>
                    value="Pantun"> Pantun </label>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-2 col-12">
        <div class="form-group">
            <div class="form-check">
                <label class="form-check-label">
                    <input type="checkbox" class="form-check-input" name="kesenian[]" 
                    <?php if (in_array("Stand Up Comedy", $minatkesenian)) echo "checked";?>
                    value="Stand Up Comedy"> Stand Up Comedy </label>
            </div>
        </div>
    </div>

</div>