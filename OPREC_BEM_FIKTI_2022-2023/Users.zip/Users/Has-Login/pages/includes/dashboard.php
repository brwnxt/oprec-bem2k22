<div class="row">
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Kastrat.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Politik dan Kesejahteraan Mahasiswa</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Akademik.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Akademik</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Bismit.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Bisnis dan Kemitraan</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Humas.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Hubungan Masyarakat</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/AU.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Administrasi Umum</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Litbang.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Penelitian dan Pengembangan</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Media.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Media</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Olahraga.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Olahraga</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Pengmas.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Pengabdian Masyarakat</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/PTI.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Pengembangan Teknologi Informasi</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/SDM.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Pengembangan Sumber Daya Manusia</h4>
            </div>
        </div>
    </div>
    <div class="col-lg-2 col-md-4 col-6 stretch-card grid-margin">
        <div class="card" style="background-color: unset !important;">
            <div class="card-body" style="padding: 0px !important; ">
                <a href=""><img src="../assets/images/Seni Budaya.png" alt="" class="img-fluid"></a>
                <h4 class="text-center text-list-logo pt-0">Seni Budaya</h4>
            </div>
        </div>
    </div>
</div>