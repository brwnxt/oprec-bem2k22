<div class="card mb-2">
    <div class="card-header" style="padding: 0px;">
        <h5 class="mb-0">
            <a class="btn" data-toggle="collapse" href="#BidangMIB" role="button" aria-expanded="true"
                aria-controls="BidangMIB" style="color: #723d90;">Bidang
                Manajemen Informasi dan Bisnis</a>
        </h5>
    </div>
    <div class="row">
        <div class="col">
            <div class="collapse multi-collapse" id="BidangMIB">
                <div class="card card-body bidang-mk">
                    <span class="mb-3">
                        Manajemen Informasi dan Bisnis (MIB) bidang yang membawahi empat biro
                        dan bertugas untuk menjaga hubungan dengan internal maupun eksternal,
                        menjadi tonggak terdepan BEM dalam menjalin kerja sama, melakukan
                        pengendalian terhadap sosial media BEM, menjadi tempat dikelolanya
                        produksi kreatif, membangun dan mengatur teknologi informasi untuk
                        keperluan BEM, mengatur dan menjaga distribusi, serta informasi untuk
                        eksternal.

                    </span>
                    <!-- Biro Media -->
                    <div class="card mb-2">
                        <div class="card-header" id="BiroMedia" style="padding: 0px;">
                            <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#Media"
                                    aria-expanded="true" aria-controls="Media" style="color: #723d90;">
                                    Biro Media
                                </button>
                            </h5>
                        </div>
                        <div id="Media" class="collapse" aria-labelledby="BiroMedia" data-parent="#accordion">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <img src="../../../assets/images/Media.png" alt="" class="images-desc-logo">
                                </div>
                                <div class="col-md-8 card-body deskripsi-dept-biro">
                                    Bertanggung jawab untuk menciptakan, mengatur design pada
                                    media BEM FIKTI UG, dan membentuk citra BEM FIKTI UG. Biro
                                    Media berperan aktif dalam menyiapkan media penyebaran
                                    informasi yang efektif dan kreatif serta mengoptimalkan
                                    fungsi media sosial BEM FIKTI UG.
                                    <hr class="col-10">
                                    <span class="text-muted" style="font-style: italic;">
                                        Benefit: Menambah pengalaman di bidang desain grafis serta mendapat pengalaman
                                        dalam berorganisasi.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Biro Humas -->
                    <div class="card mb-2">
                        <div class="card-header" id="BiroHumas" style="padding: 0px;">
                            <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#Humas"
                                    aria-expanded="true" aria-controls="Humas" style="color: #723d90;">
                                    Biro Hubungan Masyarakat ( Humas )
                                </button>
                            </h5>
                        </div>
                        <div id="Humas" class="collapse" aria-labelledby="BiroHumas" data-parent="#accordion">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <img src="../../../assets/images/Humas.png" alt="" class="images-desc-logo">
                                </div>
                                <div class="col-md-8 card-body deskripsi-dept-biro">
                                    Bertanggung jawab untuk melakukan publikasi, menjaga relasi
                                    eksternal dan internal BEM FIKTI UG, dan menjadi garda
                                    terdepan untuk citra BEM FIKTI UG. Biro Humas berperan aktif
                                    dalam mewakilkan suara BEM FIKTI UG melalui media sosial
                                    untuk menciptakan BEM FIKTI UG yang informatif.
                                    <hr class="col-10">
                                    <span class="text-muted" style="font-style: italic;">
                                        Benefit: Menambah pengalaman dalam berkomunikasi dengan pihak BEM FIKTI maupun
                                        pihak dari luar.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Biro PTI -->
                    <div class="card mb-2">
                        <div class="card-header" id="BiroPTI" style="padding: 0px;">
                            <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#PTI"
                                    aria-expanded="true" aria-controls="PTI" style="color: #723d90;">
                                    Biro Pengembangan Teknologi Informasi ( PTI )
                                </button>
                            </h5>
                        </div>
                        <div id="PTI" class="collapse" aria-labelledby="BiroPTI" data-parent="#accordion">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <img src="../../../assets/images/PTI.png" alt="" class="images-desc-logo">
                                </div>
                                <div class="col-md-8 card-body deskripsi-dept-biro">
                                    Berperan aktif untuk penerapan teknologi di lingkungan FIKTI
                                    dan BEM FIKTI UG serta bertanggung jawab untuk menciptakan
                                    dan mengembangkan teknologi di BEM FIKTI UG.
                                    <hr class="col-10">
                                    <span class="text-muted" style="font-style: italic;">
                                        Benefit: Meningkatkan kemampuan anggotanya di bidang penerapan teknologi
                                        khususnya web, dan lain sebagainya.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Biro PTI -->
                    <div class="card mb-2">
                        <div class="card-header" id="BiroBismit" style="padding: 0px;">
                            <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#Bismit"
                                    aria-expanded="true" aria-controls="Bismit" style="color: #723d90;">
                                    Biro Bisnis dan Kemitraan ( Bismit )
                                </button>
                            </h5>
                        </div>
                        <div id="Bismit" class="collapse" aria-labelledby="BiroBismit" data-parent="#accordion">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <img src="../../../assets/images/Bismit.png" alt="" class="images-desc-logo">
                                </div>
                                <div class="col-md-8 card-body deskripsi-dept-biro">
                                    Bertugas sebagai pilar perekonomian BEM FIKTI UG dengan melakukan penjualan barang
                                    berupa merchandise dan sebagainya, serta menjalin kemitraan dengan pihak-pihak
                                    eksternal untuk mensinergikan program kerja BEM FIKTI UG. Biro Bismit juga berfungsi
                                    sebagai wadah bagi para mahasiswa FIKTI UG yang berjiwa kreatif dan entrepreneur.
                                    <hr class="col-10">
                                    <span class="text-muted" style="font-style: italic;">
                                        Benefit: Meningkatkan pemasukan keuangan BEM FIKTI UG dan memperkenalkan FIKTI
                                        melalui produk-produk yang dijual oleh BEM FIKTI UG.
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>