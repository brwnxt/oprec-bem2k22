<div class="card mb-2">
    <div class="card-header" id="BidangPolKesma" style="padding: 0px;">
        <h5 class="mb-0">
            <button class="btn btn-link" data-toggle="collapse" data-target="#PolKesma" aria-expanded="true"
                aria-controls="AU" style="color: #723d90;">
                Bidang Politik dan Kesejahteraan Mahasiswa
            </button>
        </h5>
    </div>
    <div id="PolKesma" class="collapse" aria-labelledby="BidangPolKesma" data-parent="#accordion">
        <div class="row text-center">
            <div class="col-md-6 col-6 text-center">
                <img src="../../../assets/images/Adkesma.png" alt="" class="images-desc-logo-au">
                <p class="capt-logo-au">Adkesma</p>
            </div>
            <div class="col-md-6 col-6 text-center">
                <img src="../../../assets/images/Kastrat.png" alt="" class="images-desc-logo-au">
                <p class="capt-logo-au">Strategi dan Propaganda</p>
            </div>
            <div class="col-md-12 col-12 col-lg-12 deskripsi-dept-biro text-center">
                <p class="px-3">
                    Politik dan Kesejahteraan Mahasiswa (POLKESMA) adalah bidang yang bertugas sebagai penghubung dan
                    pelayanan kebutuhan terhadap mahasiswa FIKTI dengan pemangku kebijakan, pengadvokasian kebijakan
                    internal kampus terhadap isu-isu yang berkembang, serta roda penggerak dalam pergerakan mahasiswa
                    FIKTI.
                    Memiliki satu kepala dan dua deputi (Adkesma dan Strategi dan Propaganda).
                    <hr class="col-10">
                    <h4>Adkesma</h4>
                    <span class="text-muted px-2" style="font-style: italic;">
                        Benefit: Menambah relasi antar mahasiswa FIKTI UG baik jurusan Sistem Informasi dan Sistem
                        Komputer, ikut serta dalam membangun FIKTI UG yang lebih baik lagi ke depannya, dan
                        mensejahterakan mahasiswa FIKTI UG.
                    </span>
                    <hr class="col-10">
                    <h4>Strategi dan Propaganda</h4>
                    <span class="text-muted px-2" style="font-style: italic;">
                        Benefit: Berperan sebagai roda penggerak dalam pergerakan mahasiswa FIKTI.
                    </span>
                </p>
            </div>
        </div>
    </div>
</div>